# Adventure Besties API

A Node Express API service running on AWS Lambda using the Serverless Framework.
